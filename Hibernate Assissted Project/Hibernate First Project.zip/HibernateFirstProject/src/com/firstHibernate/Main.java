package com.firstHibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.Service;
import org.hibernate.service.ServiceRegistry;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metadata=new MetadataSources(registry).getMetadataBuilder().build();
		//connection pool
		SessionFactory factory=metadata.getSessionFactoryBuilder().build();
		//lets take database connection to do transaction
		
		//prepare one database in mysql
		
		Session session=factory.openSession();
		
		Student s1=new Student();
		s1.setName("Sweatha");
		s1.setEmail("sweatha@gmail.com");
		s1.setPassword("sweatha123");
		
		Transaction tx=session.beginTransaction();
		session.save(s1);
		
		tx.commit();
		
		session.close();
		factory.close();
		
		System.out.println("Data Inserted Successfully");

	}

}
