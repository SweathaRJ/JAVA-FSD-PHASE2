package com.validation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String emaiId=req.getParameter("emailId");
		String password=req.getParameter("password");
		
		
		System.out.println("emailId.."+emaiId);
		System.out.println("password.."+password);
		
		if(emaiId!=null && emaiId.equalsIgnoreCase("admin@gmail.com") && password!=null && password.equalsIgnoreCase("admin")) {
			HttpSession session=req.getSession();
			session.setAttribute("emaiId", emaiId);
			req.getRequestDispatcher("welcome.html").forward(req, resp);
			
	     }
		else {
			System.out.println("Invalid emailId");
		}
	}
	
	

}
